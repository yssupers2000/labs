import os
import glob
import argparse
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score


def load_first_csv(path: str) -> pd.DataFrame:
    # Azure ML v2는 uri_file도 폴더로 마운트되는 경우가 있어 폴더/파일 모두 처리
    if os.path.isdir(path):
        csv_files = glob.glob(os.path.join(path, "*.csv"))
        if not csv_files:
            raise RuntimeError(f"No CSV in folder: {path}")
        return pd.read_csv(csv_files[0])
    return pd.read_csv(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_data", type=str, required=True)
    parser.add_argument("--test_data", type=str, required=True)
    parser.add_argument("--n_clusters", type=int, default=3)
    parser.add_argument("--random_state", type=int, default=42)
    parser.add_argument("--sweep_k_range", type=str, default="2,3,4,5")
    parser.add_argument("--scored_data", type=str, required=True)
    parser.add_argument("--evaluation_metrics", type=str, required=True)
    args = parser.parse_args()

    print("Loading data...")
    df_train = load_first_csv(args.train_data)
    df_test = load_first_csv(args.test_data)

    numeric_cols = df_train.select_dtypes(include=["float64", "int64"]).columns
    X_train = df_train[numeric_cols].fillna(0)
    X_test = df_test[numeric_cols].fillna(0)

    k_values = [int(k.strip()) for k in args.sweep_k_range.split(",") if k.strip()]
    print(f"Sweeping K values: {k_values}")

    best_k = None
    best_score = float("-inf")
    best_labels = None

    for k in k_values:
        kmeans = KMeans(n_clusters=k, random_state=args.random_state)
        kmeans.fit(X_train)
        labels = kmeans.predict(X_test)

        try:
            score = silhouette_score(X_test, labels)
            print(f"K={k} -> Silhouette Score: {score:.4f}")

            if score > best_score:
                best_score = score
                best_k = k
                best_labels = labels
        except Exception as e:
            print(f"K={k} -> Could not compute score ({e})")

    if best_labels is None:
        raise RuntimeError("Sweep failed: no valid K produced labels/scores.")

    print(f"Best K: {best_k} (Score: {best_score:.4f})")

    result_df = df_test.copy()
    result_df["Assignments"] = best_labels
    result_df.to_csv(args.scored_data, index=False)

    metrics_df = pd.DataFrame(
        {"Metric": ["Best_K", "Silhouette_Score"], "Value": [best_k, best_score]}
    )
    metrics_df.to_csv(args.evaluation_metrics, index=False)

    print("Done!")


if __name__ == "__main__":
    main()
