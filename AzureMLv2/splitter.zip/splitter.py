import argparse
import pandas as pd
import os
import glob
from sklearn.model_selection import train_test_split
import re

# --- [공통] 스마트 파일 찾기 함수 ---
def get_csv_file(path):
    if not path: return None
    if os.path.isfile(path) or path.lower().endswith('.csv'): return path
    if os.path.isdir(path):
        files = glob.glob(os.path.join(path, "*.csv"))
        if not files: raise FileNotFoundError(f"No CSV files found in: {path}")
        return files[0]
    raise FileNotFoundError(f"Invalid path: {path}")

# --- 메인 ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_data", type=str, required=True)
    parser.add_argument("--output_train", type=str, required=True)
    parser.add_argument("--output_test", type=str, required=True)
    
    # 분할 모드 선택 (random / year / regex)
    parser.add_argument("--mode", type=str, default="random", choices=["random", "year", "regex"])
    
    # [Random 모드용]
    parser.add_argument("--test_size", type=float, default=0.3)
    parser.add_argument("--random_state", type=int, default=42)
    
    # [Year 모드용]
    parser.add_argument("--year_column", type=str, default="Year")
    parser.add_argument("--test_year", type=int, default=2014)

    # [Regex 모드용] (v1 스타일)
    parser.add_argument("--regex_column", type=str, default="YrPlayer", help="정규식을 적용할 컬럼명")
    parser.add_argument("--regex_pattern", type=str, default="", help="Train 데이터에 남길 정규식 패턴")

    args = parser.parse_args()

    # 1. 데이터 로드
    input_path = get_csv_file(args.input_data)
    try:
        df = pd.read_csv(input_path, encoding='utf-8')
    except:
        df = pd.read_csv(input_path, encoding='cp949')

    print(f"Original data shape: {df.shape}")

    # --- 분할 로직 ---
    if args.mode == "random":
        print(f">>> Mode: Random Split (Test Size: {args.test_size})")
        train_df, test_df = train_test_split(
            df, test_size=args.test_size, random_state=args.random_state
        )

    elif args.mode == "year":
        print(f">>> Mode: Year Split (Test Year: {args.test_year})")
        if args.year_column not in df.columns:
            raise ValueError(f"Column '{args.year_column}' not found.")
        
        train_df = df[df[args.year_column] < args.test_year].copy()
        test_df = df[df[args.year_column] == args.test_year].copy()

    elif args.mode == "regex":
        print(f">>> Mode: Regex Split (Column: {args.regex_column}, Pattern: {args.regex_pattern})")
        if args.regex_column not in df.columns:
            raise ValueError(f"Column '{args.regex_column}' not found.")
        
        if not args.regex_pattern:
             raise ValueError("Regex pattern is required for regex mode.")

        # 정규식 필터링 (str.match 또는 contains 사용)
        # v1과 똑같이: 패턴에 매칭되는 행을 '첫 번째 데이터셋(Train)'으로 보냄
        # 예: ^((?!2014).)*$  -> 2014가 포함되지 않은 것들을 Train으로
        
        mask = df[args.regex_column].astype(str).str.contains(args.regex_pattern, regex=True)
        
        train_df = df[mask].copy()
        test_df = df[~mask].copy()

    # --- 결과 출력 ---
    print(f"Train shape: {train_df.shape} ({len(train_df)/len(df)*100:.1f}%)")
    print(f"Test shape: {test_df.shape} ({len(test_df)/len(df)*100:.1f}%)")

    # 저장
    os.makedirs(args.output_train, exist_ok=True)
    train_df.to_csv(os.path.join(args.output_train, "data.csv"), index=False)
    
    os.makedirs(args.output_test, exist_ok=True)
    test_df.to_csv(os.path.join(args.output_test, "data.csv"), index=False)
