import argparse
import pandas as pd
import os
import glob
from sklearn.preprocessing import MinMaxScaler, StandardScaler

# --- [공통] 스마트 파일 찾기 함수 ---
def get_csv_file(path):
    if not path: return None
    if os.path.isfile(path) or path.lower().endswith('.csv'): return path
    if os.path.isdir(path):
        files = glob.glob(os.path.join(path, "*.csv"))
        if not files: raise FileNotFoundError(f"No CSV files found in: {path}")
        return files[0]
    raise FileNotFoundError(f"Invalid path: {path}")

# --- 메인 ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_data", type=str, required=True)
    parser.add_argument("--output_data", type=str, required=True)
    parser.add_argument("--mode", type=str, default="minmax", choices=["minmax", "standard"])
    # YAML에서 빈 문자열("")로 넘어와도 처리되도록 default 설정
    parser.add_argument("--columns", type=str, default="", required=False)

    args = parser.parse_args()

    # 1. 데이터 로드
    input_path = get_csv_file(args.input_data)
    try:
        df = pd.read_csv(input_path, encoding='utf-8')
    except:
        df = pd.read_csv(input_path, encoding='cp949')

    # 2. 적용할 컬럼 선정
    # 값이 있고 빈 문자열이 아니면 -> 사용자 지정 컬럼 사용
    if args.columns and args.columns.strip() != "":
        print(f"User selected columns: {args.columns}")
        raw_cols = [c.strip() for c in args.columns.split(",")]
        # 실제 데이터에 있는 것만 필터링
        target_cols = [c for c in raw_cols if c in df.columns]
        if not target_cols:
            print(f"[Warning] 입력한 컬럼 {raw_cols} 중 데이터에 존재하는 것이 없습니다.")
    else:
        # 입력이 없으면 -> 모든 숫자형(int, float) 컬럼 자동 선택
        target_cols = df.select_dtypes(include=['number']).columns.tolist()
        print(f"Auto-selected numeric columns: {target_cols}")

    # 3. 변환 수행
    if not target_cols:
        print("[Info] 변환할 대상 컬럼이 없습니다. 원본 그대로 저장합니다.")
        df_processed = df
    else:
        if args.mode == "minmax":
            print(">>> Mode: MinMax Scaling (0~1)")
            scaler = MinMaxScaler()
        elif args.mode == "standard":
            print(">>> Mode: Standard Scaling (Z-score)")
            scaler = StandardScaler()
        
        # 원본 복사 후 변환
        df_processed = df.copy()
        df_processed[target_cols] = scaler.fit_transform(df[target_cols])

    # 4. 저장
    os.makedirs(args.output_data, exist_ok=True)
    output_path = os.path.join(args.output_data, "data.csv")
    df_processed.to_csv(output_path, index=False)
    print(f"Saved normalized data to {output_path}")
