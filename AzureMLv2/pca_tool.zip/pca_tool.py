import argparse
import pandas as pd
import os
import glob
from sklearn.decomposition import PCA

# --- [공통] 스마트 파일 찾기 함수 ---
def get_csv_file(path):
    if not path: return None
    if os.path.isfile(path) or path.lower().endswith('.csv'): return path
    if os.path.isdir(path):
        files = glob.glob(os.path.join(path, "*.csv"))
        if not files: raise FileNotFoundError(f"No CSV files found in: {path}")
        return files[0]
    raise FileNotFoundError(f"Invalid path: {path}")

# --- 메인 ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_data", type=str, required=True)
    parser.add_argument("--output_data", type=str, required=True)
    parser.add_argument("--n_components", type=int, default=8)
    parser.add_argument("--id_column", type=str, default="YrPlayer", help="PCA에서 제외하고 맨 앞에 붙일 ID 컬럼명")

    args = parser.parse_args()

    # 1. 데이터 로드
    input_path = get_csv_file(args.input_data)
    try:
        df = pd.read_csv(input_path, encoding='utf-8')
    except:
        df = pd.read_csv(input_path, encoding='cp949')

    # 2. ID 컬럼 분리 (없으면 에러 대신 경고 후 전체 사용)
    if args.id_column in df.columns:
        print(f"ID Column '{args.id_column}' detected. Separating it from PCA.")
        ids = df[args.id_column]
        features = df.drop(columns=[args.id_column])
    else:
        print(f"[Warning] ID Column '{args.id_column}' not found. Using all columns for PCA.")
        ids = None
        features = df

    # 3. PCA 수행
    # (문자열 컬럼이 남아있으면 에러 나므로 숫자만 선택)
    numeric_features = features.select_dtypes(include=['number'])
    
    print(f"Running PCA with n_components={args.n_components} on {numeric_features.shape[1]} columns...")
    
    pca = PCA(n_components=args.n_components)
    X_pca = pca.fit_transform(numeric_features)

    # 4. 결과 DataFrame 생성 (PC1, PC2...)
    col_names = [f'PC{i+1}' for i in range(args.n_components)]
    extracted = pd.DataFrame(data=X_pca, columns=col_names)

    # 5. ID 컬럼 다시 붙이기 (맨 앞에)
    if ids is not None:
        extracted.insert(0, args.id_column, ids)

    # 6. 저장
    os.makedirs(args.output_data, exist_ok=True)
    output_path = os.path.join(args.output_data, "data.csv")
    extracted.to_csv(output_path, index=False)
    
    print(f"PCA completed. Shape: {extracted.shape}")
    print(f"Explained Variance Ratio: {pca.explained_variance_ratio_}")
    print(f"Saved to {output_path}")
