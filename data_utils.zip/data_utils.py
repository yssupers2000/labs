import argparse
import pandas as pd
import os
import glob

# --- [수정된 부분] 스마트한 파일 찾기 함수 ---
def get_csv_file(path):
    # 1. 입력이 없는 경우 (None 처리)
    if not path:
        return None

    # 2. 경로 자체가 파일인 경우 (또는 문자열 끝이 .csv인 경우)
    if os.path.isfile(path) or path.lower().endswith('.csv'):
        return path

    # 3. 폴더인 경우, 그 안에서 csv 찾기
    if os.path.isdir(path):
        files = glob.glob(os.path.join(path, "*.csv"))
        if not files:
            raise FileNotFoundError(f"No CSV files found in directory: {path}")
        return files[0]
    
    # 4. 예외 처리
    raise FileNotFoundError(f"Invalid path: {path}")

# --- 메인 로직 시작 ---
if __name__ == "__main__":
    # 1. 인자 파싱 (Azure와 소통하는 부분 - 필수!)
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_data", type=str)
    parser.add_argument("--input_data_2", type=str, required=False) # Add Rows용
    parser.add_argument("--output_data", type=str)
    parser.add_argument("--mode", type=str, default="select_columns", choices=["select_columns", "add_rows"])
    parser.add_argument("--columns", type=str, required=False) # "Year,Player,AVG" 등

    args = parser.parse_args()

    # 2. 첫 번째 데이터 로드
    input_path = get_csv_file(args.input_data)
    
    # 인코딩 처리 (한글 깨짐 방지)
    try:
        df = pd.read_csv(input_path, encoding='utf-8')
    except UnicodeDecodeError:
        df = pd.read_csv(input_path, encoding='cp949')

    # --- [기능 1] 컬럼 선택 모드 ---
    if args.mode == "select_columns":
        print(f">>> Mode: Select Columns from {input_path}")
        if not args.columns:
            raise ValueError("select_columns 모드에서는 --columns 인자가 필수입니다.")
        
        # 입력받은 문자열을 리스트로 변환 (공백 제거)
        target_cols = [c.strip() for c in args.columns.split(",")]
        
        # 실제 데이터에 있는 컬럼만 골라내기
        available_cols = [c for c in target_cols if c in df.columns]
        
        if not available_cols:
             raise ValueError(f"입력한 컬럼 중 데이터에 존재하는 게 하나도 없습니다.\n요청: {target_cols}\n실제: {df.columns.tolist()}")

        df_processed = df[available_cols]

    # --- [기능 2] 합치기 모드 (Add Rows) ---
    elif args.mode == "add_rows":
        print(">>> Mode: Add Rows (Concat)")
        if not args.input_data_2:
            raise ValueError("add_rows 모드에서는 --input_data_2가 필수입니다.")
        
        # 두 번째 데이터 로드
        input_path_2 = get_csv_file(args.input_data_2)
        try:
            df_2 = pd.read_csv(input_path_2, encoding='utf-8')
        except UnicodeDecodeError:
            df_2 = pd.read_csv(input_path_2, encoding='cp949')
        
        # 교집합 컬럼 찾기
        common_cols = list(set(df.columns) & set(df_2.columns))
        if not common_cols:
             raise ValueError("두 데이터 간에 공통된 컬럼 이름이 하나도 없습니다! 합칠 수 없습니다.")

        print(f"공통 컬럼({len(common_cols)}개) 기준으로 합칩니다.")
        
        # 순서 통일해서 합치기
        df_processed = pd.concat([df[common_cols], df_2[common_cols]], ignore_index=True)

    # 3. 결과 저장
    os.makedirs(args.output_data, exist_ok=True)
    output_path = os.path.join(args.output_data, "data.csv")
    df_processed.to_csv(output_path, index=False)
    print(f"Saved processed data to {output_path}")